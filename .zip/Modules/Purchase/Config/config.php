<?php

return [
    'name' => 'Purchase'
];
